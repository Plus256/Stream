<?php
?>
<div id="extra_info">
    <div id="contr">
        <?php echo $long_descr; ?>
    </div>
</div>
<?php
?>