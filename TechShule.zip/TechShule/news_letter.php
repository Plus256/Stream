<?php
?>
<div id="news_l">
    <div id="news_l_head">NEWSLETTERS</div>
    <div id="news_l_body">
        <div id="news_l_form">
            <form>
                <input type="text" id="news_l_email" placeholder="Email Address" />
                <input type="button" value="SUBSCRIBE" id="subscr_but" />
            </form>
            <div class="spacer"></div>
        </div>
        <div id="news_l_fedb"></div>
        <div class="spacer"></div>
    </div>
</div>
<?php
?>