<div id="adm_dashboard">
	<div class="wrapper">
    	<a href="<?php echo $_SERVER['PHP_SELF']; ?>?option=Shules" class="adm_dashboard_itm">
            <div>
                <div class="icon" id="reviews_icon"></div><div class="icon_label">Shules</div>
            </div>
        </a>
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>?option=Ads" class="adm_dashboard_itm">
            <div>
                <div class="icon" id="tips_icon"></div><div class="icon_label">Ads</div>
            </div>
        </a>
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>?option=Events" class="adm_dashboard_itm">
            <div>
                <div class="icon" id="courses_icon"></div><div class="icon_label">Events</div>
            </div>
        </a>
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>?option=Jobs" class="adm_dashboard_itm">
            <div>
                <div class="icon" id="analytics_icon"></div><div class="icon_label">Jobs</div>
            </div>
        </a>
        <a href="<?php echo $_SERVER['PHP_SELF']; ?>?option=Users" class="adm_dashboard_itm">
            <div>
                <div class="icon" id="users_icon"></div><div class="icon_label">Users</div>
            </div>
        </a>
    	<div class="spacer"></div>
    </div>
</div>