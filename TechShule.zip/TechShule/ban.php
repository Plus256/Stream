<div id="banner">
	<div class="wrapper">
    	<div id="name_logo">
        	<a href="./"><div id="logo"><img src="<?php echo $logo; ?>" /></div><div id="short_name"><?php echo $short_name; ?></div></a>
        </div>
        <?php require_once("menu.php"); ?>
    	<div class="spacer"></div>
    </div>
</div>