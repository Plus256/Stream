<div id="footer">
	<div class="wrapper">
        <div id="fot_soc">
            <a href="https://www.facebook.com/techshule" target="_NEW"><img src="gra/facebook.png" /></a>
            <a href="https://www.twitter.com/@techshule" target="_NEW"><img src="gra/twitter.png" /></a>
            <a href="https://www.google.com/+techshule" target="_NEW"><img src="gra/google.png" /></a>
            <div class="spacer"></div>
        </div>
    	<div id="fot_links">
            <a href="#" id="about_fot_link">About</a>
            <a href="#" id="contact_fot_link">Contact</a>
            <a href="#" id="ad_fot_link">Advertise</a>
            <a href="#" id="contr_fot_link">Contribute</a>
            <a href="#" id="terms_fot_link">Terms</a>
            <div class="spacer"></div>
        </div>
        <div id="copyright">Copyright &copy; <?php echo date('Y'). " <a href='http://www.plus256.com'>".$power."</a>"; ?></div>
    	<div class="spacer"></div>
    </div>
    <div id="fb-root"></div>
</div>
</body>
</html>
<?php
ob_end_flush();
?>