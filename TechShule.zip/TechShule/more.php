<div id="more_shule_content">
    <div class="wrapper">
    	<div id="more_shule_left">
    	    <?php require_once("dsh.php");//acting as the placeholder element ?>
    	    <div id="more_shule_left_this"></div>
            <div id="more_shule_left_more">
                <div id="shule_left_left_container"></div>
                <div id="shule_left_right_container"></div>
                <div id="load_more_but">Load More</div>
            </div>
        </div>
        <?php require_once("ad_extra.php"); ?>
        <div class="spacer"></div>
    </div>
</div>