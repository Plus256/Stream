<?php
?>
<div id="twt_feed">
    <!--<div id="twt_feed_title">
        <span id="twt_feed_title_logo"><img src="gra/twitter.png" ></span>
        <span id="twt_feed_title_name"> @TechShule</span>
    </div>-->
    <div id="twt_feed_body">
        <a id="desktop" class="twitter-timeline" href="https://twitter.com/TechShule" data-widget-id="566523514233319424"></a>
        <a id="mobile" class="twitter-timeline" href="https://twitter.com/TechShule" data-widget-id="566523514233319424" data-tweet-limit="2"></a>
    </div>
    <div class="spacer"></div>
</div>
<div class="spacer"></div>
<?php
?>