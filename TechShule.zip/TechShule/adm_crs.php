<div class="adm_opt_ctrl">
	<div class="wrapper">
    	<div class="adm_opt_ctrl_task_p">
        	<?php echo $opt." "; ?>Tasks
        </div>
        <div class="adm_opt_ctrl_cont_p">
        	<?php echo $opt." "; ?>Content
        </div>
    	<div class="spacer"></div>
    </div>
</div>