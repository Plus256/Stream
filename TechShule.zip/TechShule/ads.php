<?php
?>
<div id="extra_ad"></div>
<?php
?>