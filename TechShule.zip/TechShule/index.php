<?php
require_once("hed.php");
require_once("ban.php");
require_once("bod.php");
require_once("fot.php");
?>