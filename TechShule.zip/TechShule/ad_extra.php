<?php
?>
<div id="shule_right_container">
    <?php require_once("info.php"); ?>
    <?php require_once("ads.php"); ?>
    <?php require_once("events.php"); ?>
    <?php require_once("news_letter.php"); ?>
    <div class="spacer"></div>
</div>
<?php
?>