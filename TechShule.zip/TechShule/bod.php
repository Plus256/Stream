<div id="main_content">
    <div class="wrapper">
    	<div id="shule_left_container">
    	    <?php require_once("dsh.php"); ?>
    	    <div id="shule_left_left_container">
            </div>
            <div id="shule_left_right_container">
            </div>
            <div id="load_more_but">Load More</div>
        </div>
        <?php require_once("ad_extra.php"); ?>
        <div class="spacer"></div>
    </div>
</div>